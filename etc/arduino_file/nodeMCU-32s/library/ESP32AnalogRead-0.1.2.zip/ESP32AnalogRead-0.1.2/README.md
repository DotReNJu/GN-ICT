# ESP32AnalogRead
Load the calibration data and provide a calibrated analog read

# Documentation by Doxygen

[ESP32AnalogRead Doxygen](https://madhephaestus.github.io/ESP32AnalogRead/files.html)

